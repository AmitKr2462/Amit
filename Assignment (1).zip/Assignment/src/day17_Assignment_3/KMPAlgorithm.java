
/*Task 3: Implementing the KMP Algorithm

Code the Knuth-Morris-Pratt (KMP) algorithm in Java for pattern searching which 
pre-processes the pattern to reduce the number of comparisons. Explain how this pre-processing 
improves the search time compared to the naive approach.*/

package day17_Assignment_3;

public class KMPAlgorithm {

	private int[] computeLPSArray(String pattern) {
		int M = pattern.length();
		int[] lps = new int[M];
		int len = 0; 
		int i = 1;
		lps[0] = 0; 

		while (i < M) {
			if (pattern.charAt(i) == pattern.charAt(len)) {
				len++;
				lps[i] = len;
				i++;
			} else {
				if (len != 0) {
					len = lps[len - 1];
				} else {
					lps[i] = len;
					i++;
				}
			}
		}
		return lps;
	}

	
	public void KMPSearch(String pattern, String text) {
		int M = pattern.length();
		int N = text.length();
		int[] lps = computeLPSArray(pattern);
		int i = 0; 
		int j = 0; 

		while (i < N) {
			if (pattern.charAt(j) == text.charAt(i)) {
				i++;
				j++;
			}

			if (j == M) {
				System.out.println("Found pattern at index " + (i - j));
				j = lps[j - 1];
			} else if (i < N && pattern.charAt(j) != text.charAt(i)) {
				if (j != 0) {
					j = lps[j - 1];
				} else {
					i++;
				}
			}
		}
	}

	public static void main(String[] args) {
		KMPAlgorithm kmp = new KMPAlgorithm();
		String text = "ABABDABACDABABCABAB";
		String pattern = "ABABCABAB";
		kmp.KMPSearch(pattern, text);
	}

}
