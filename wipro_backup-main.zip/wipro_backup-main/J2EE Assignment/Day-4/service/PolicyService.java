package com.example.policyadminbackend.service;


import org.springframework.stereotype.Service;

@Service
public class PolicyService {
    // Business logic related to policies
}
