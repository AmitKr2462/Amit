package com.example.policyadminbackend;

public class SomeBean {

    public void someMethod() {
        // Define functionality of SomeBean
        System.out.println("SomeBean method called");
    }
}
