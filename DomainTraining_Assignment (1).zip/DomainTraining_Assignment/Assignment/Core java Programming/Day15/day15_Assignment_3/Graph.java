/*Task 3: Union-Find for Cycle Detection
Write a Union-Find data structure with path compression. Use this data structure to detect
a cycle in an undirected graph.*/

package day15_Assignment_3;
import java.util.*;

public class Graph {
	
	 private int V; // Number of vertices
	    private List<int[]> edges; // List of edges

	    public Graph(int V) {
	        this.V = V;
	        edges = new ArrayList<>();
	    }

	    public void addEdge(int u, int v) {
	        edges.add(new int[]{u, v});
	    }

	    public boolean hasCycle() {
	        UnionFind uf = new UnionFind(V);

	        for (int[] edge : edges) {
	            int u = edge[0];
	            int v = edge[1];

	            if (!uf.union(u, v)) {
	                return true; // Cycle detected
	            }
	        }
	        return false; // No cycle detected
	    }

	    public static void main(String[] args) {
	        Graph g = new Graph(3);
	        g.addEdge(0, 1);
	        g.addEdge(1, 2);
	        g.addEdge(0, 2);

	        if (g.hasCycle()) {
	            System.out.println("Graph contains a cycle");
	        } else {
	            System.out.println("Graph doesn't contain a cycle");
	        }
	    }

}
