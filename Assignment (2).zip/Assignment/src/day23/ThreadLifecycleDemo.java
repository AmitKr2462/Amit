package day23;

public class ThreadLifecycleDemo {

	private static final Object monitor = new Object();

	public static void main(String[] args) {
		Thread thread = new Thread(new DemoRunnable(), "DemoThread");

		System.out.println("State after thread creation: " + thread.getState());

		thread.start();

		System.out.println("State after thread start: " + thread.getState());

		try {
			Thread.sleep(100);
			synchronized (monitor) {
				monitor.notify();
			}
			Thread.sleep(100);

			thread.join();

			System.out.println("State after thread completion: " + thread.getState());
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	static class DemoRunnable implements Runnable {
		@Override
		public void run() {
			synchronized (monitor) {
				try {

					System.out.println("State while sleeping: " + Thread.currentThread().getState());
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

				try {

					System.out.println("State before waiting: " + Thread.currentThread().getState());
					monitor.wait();
					System.out.println("State after waiting: " + Thread.currentThread().getState());
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

				try {

					System.out.println("Attempting to enter synchronized block");
					synchronized (this) {
						System.out.println("Entered synchronized block");
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

}
