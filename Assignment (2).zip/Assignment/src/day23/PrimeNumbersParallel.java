package day23;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class PrimeNumbersParallel {

	public static void main(String[] args) {
		int upperLimit = 1000;
		int numThreads = 4;

		ExecutorService executorService = Executors.newFixedThreadPool(numThreads);

		try {

			List<Future<List<Integer>>> futures = new ArrayList<>();
			int chunkSize = upperLimit / numThreads;

			for (int i = 0; i < numThreads; i++) {
				int start = i * chunkSize + 1;
				int end = (i == numThreads - 1) ? upperLimit : (i + 1) * chunkSize;
				futures.add(executorService.submit(new PrimeCalculatorTask(start, end)));
			}

			List<Integer> primes = new ArrayList<>();
			for (Future<List<Integer>> future : futures) {
				primes.addAll(future.get());
			}

			CompletableFuture<Void> writeFuture = CompletableFuture.runAsync(() -> {
				try {
					writePrimesToFile(primes, "primes.txt");
				} catch (IOException e) {
					e.printStackTrace();
				}
			});

			writeFuture.join();

			System.out.println("Prime numbers calculated and written to file.");

		} catch (InterruptedException | ExecutionException e) {
			e.printStackTrace();
		} finally {

			executorService.shutdown();
		}
	}

	static class PrimeCalculatorTask implements Callable<List<Integer>> {
		private final int start;
		private final int end;

		PrimeCalculatorTask(int start, int end) {
			this.start = start;
			this.end = end;
		}

		@Override
		public List<Integer> call() {
			return IntStream.rangeClosed(start, end).filter(this::isPrime).boxed().collect(Collectors.toList());
		}

		private boolean isPrime(int number) {
			if (number < 2)
				return false;
			for (int i = 2; i <= Math.sqrt(number); i++) {
				if (number % i == 0)
					return false;
			}
			return true;
		}
	}

	private static void writePrimesToFile(List<Integer> primes, String fileName) throws IOException {
		List<String> lines = primes.stream().map(String::valueOf).collect(Collectors.toList());
		Files.write(Paths.get(fileName), lines);
	}

}
