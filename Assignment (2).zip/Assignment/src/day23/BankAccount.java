package day23;

public class BankAccount {

	private double balance;

	public BankAccount(double balance) {
		this.balance = balance;
	}

	public synchronized void deposit(double amount) {
		if (amount > 0) {
			balance += amount;
			System.out.println(Thread.currentThread().getName() + " deposited " + amount + ", new balance: " + balance);
		}
	}

	public synchronized void withdraw(double amount) {
		if (amount > 0 && amount <= balance) {
			balance -= amount;
			System.out.println(Thread.currentThread().getName() + " withdrew " + amount + ", new balance: " + balance);
		} else {
			System.out.println(
					Thread.currentThread().getName() + " tried to withdraw " + amount + ", but insufficient balance.");
		}
	}

	public static void main(String[] args) {
		BankAccount account = new BankAccount(1000);

		Runnable depositTask = () -> {
			for (int i = 0; i < 5; i++) {
				account.deposit(100);
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		};

		Runnable withdrawTask = () -> {
			for (int i = 0; i < 5; i++) {
				account.withdraw(50);
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		};

		Thread thread1 = new Thread(depositTask, "Thread-1");
		Thread thread2 = new Thread(withdrawTask, "Thread-2");

		thread1.start();
		thread2.start();
	}

}
