package day23;

class Pair1<T, U> {
	private final T first;
	private final U second;

	public Pair1(T first, U second) {
		this.first = first;
		this.second = second;
	}

	public T getFirst() {
		return first;
	}

	public U getSecond() {
		return second;
	}

	public Pair1<U, T> reverse() {
		return new Pair1<>(second, first);
	}

	@Override
	public String toString() {
		return "Pair1{" + "first=" + first + ", second=" + second + '}';
	}

	public static void main(String[] args) {
		Pair1<Integer, String> pair = new Pair1<>(1, "one");
		System.out.println("Original Pair: " + pair);

		Pair1<String, Integer> reversedPair = pair.reverse();
		System.out.println("Reversed Pair: " + reversedPair);
	}
}
