package day23;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ThreadPoolExample {

	public static void main(String[] args) {

		ExecutorService executorService = Executors.newFixedThreadPool(4);

		Future<Long>[] futures = new Future[10];
		for (int i = 0; i < 10; i++) {
			int number = i + 10;
			futures[i] = executorService.submit(new FactorialTask(number));
		}

		for (int i = 0; i < 10; i++) {
			try {
				System.out.println("Factorial of " + (i + 10) + " is: " + futures[i].get());
			} catch (InterruptedException | ExecutionException e) {
				e.printStackTrace();
			}
		}

		executorService.shutdown();
	}

	static class FactorialTask implements Callable<Long> {
		private final int number;

		FactorialTask(int number) {
			this.number = number;
		}

		@Override
		public Long call() {
			return factorial(number);
		}

		private Long factorial(int n) {
			long result = 1;
			for (int i = 2; i <= n; i++) {
				result *= i;
			}
			return result;
		}
	}

}
