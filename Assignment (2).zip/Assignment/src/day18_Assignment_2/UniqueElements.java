/*Task 2: Unique Elements Identification
Given an array of integers where every element appears twice except for two, write a function that 
efficiently finds these two non-repeating elements using bitwise XOR operations.*/

package day18_Assignment_2;

public class UniqueElements {

	public static int[] findUniqueElements(int[] nums) {

		int xor = 0;
		for (int num : nums) {
			xor ^= num;
		}

		int setBit = xor & -xor;

		int unique1 = 0, unique2 = 0;
		for (int num : nums) {
			if ((num & setBit) == 0) {
				unique1 ^= num;
			} else {
				unique2 ^= num;
			}
		}

		return new int[] { unique1, unique2 };
	}

	public static void main(String[] args) {
		int[] nums = { 1, 2, 1, 3, 2, 5 };
		int[] result = findUniqueElements(nums);
		System.out.println("The two unique elements are: " + result[0] + " and " + result[1]);
	}

}
