/*Task 1: Dijkstra�s Shortest Path Finder
Code Dijkstra�s algorithm to find the shortest path from a start node to every other node in a
weighted graph with positive weights.*/

package day15_Assignment_1;
import java.util.*;

public class Dijkstra {

	private int V; // Number of vertices
	private List<List<Node>> adj; // Adjacency list

	class Node implements Comparable<Node> {
		int vertex;
		int weight;

		Node(int v, int w) {
			vertex = v;
			weight = w;
		}

		@Override
		public int compareTo(Node other) {
			return Integer.compare(this.weight, other.weight);
		}
	}

	public Dijkstra(int V) {
		this.V = V;
		adj = new ArrayList<>(V);
		for (int i = 0; i < V; i++) {
			adj.add(new LinkedList<>());
		}
	}

	public void addEdge(int u, int v, int weight) {
		adj.get(u).add(new Node(v, weight));
		adj.get(v).add(new Node(u, weight)); // For undirected graph
	}

	public int[] dijkstra(int start) {
		PriorityQueue<Node> pq = new PriorityQueue<>();
		int[] dist = new int[V];
		Arrays.fill(dist, Integer.MAX_VALUE);
		dist[start] = 0;
		pq.add(new Node(start, 0));

		while (!pq.isEmpty()) {
			Node node = pq.poll();
			int u = node.vertex;

			for (Node neighbor : adj.get(u)) {
				int v = neighbor.vertex;
				int weight = neighbor.weight;

				if (dist[u] + weight < dist[v]) {
					dist[v] = dist[u] + weight;
					pq.add(new Node(v, dist[v]));
				}
			}
		}

		return dist;
	}

	public static void main(String[] args) {
		Dijkstra g = new Dijkstra(5);
		g.addEdge(0, 1, 10);
		g.addEdge(0, 4, 3);
		g.addEdge(1, 2, 2);
		g.addEdge(1, 4, 4);
		g.addEdge(2, 3, 9);
		g.addEdge(3, 2, 7);
		g.addEdge(4, 1, 1);
		g.addEdge(4, 2, 8);
		g.addEdge(4, 3, 2);

		int[] distances = g.dijkstra(0);

		System.out.println("Vertex\tDistance from Source");
		for (int i = 0; i < distances.length; i++) {
			System.out.println(i + "\t" + distances[i]);
		}
	}

}
