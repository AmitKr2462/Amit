/*Task 3: Reflection API 
Use reflection to inspect a class's methods, fields, and constructors, and modify the access level 
of a private field, setting its value during runtime*/

package day24;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

class SampleClass {
	private String privateField = "Initial Value";

	public SampleClass() {
		System.out.println("Default Constructor");
	}

	public SampleClass(String param) {
		System.out.println("Parameterized Constructor: " + param);
	}

	private void privateMethod() {
		System.out.println("Private Method");
	}

	public void publicMethod() {
		System.out.println("Public Method");
	}

	public String getPrivateField() {
		return privateField;
	}
}

public class ReflectionExample {

	public static void main(String[] args) {
		try {

			Class<?> sampleClass = Class.forName("SampleClass");

			System.out.println("Fields:");
			Field[] fields = sampleClass.getDeclaredFields();
			for (Field field : fields) {
				System.out.println(" - " + field.getName());
			}

			System.out.println("Methods:");
			Method[] methods = sampleClass.getDeclaredMethods();
			for (Method method : methods) {
				System.out.println(" - " + method.getName());
			}

			System.out.println("Constructors:");
			Constructor<?>[] constructors = sampleClass.getDeclaredConstructors();
			for (Constructor<?> constructor : constructors) {
				System.out.println(" - " + constructor);
			}

			Object sampleInstance = sampleClass.getDeclaredConstructor().newInstance();

			Field privateField = sampleClass.getDeclaredField("privateField");
			privateField.setAccessible(true);
			privateField.set(sampleInstance, "Modified Value");

			Method getPrivateFieldMethod = sampleClass.getDeclaredMethod("getPrivateField");
			String modifiedValue = (String) getPrivateFieldMethod.invoke(sampleInstance);
			System.out.println("Modified Private Field Value: " + modifiedValue);

			Method privateMethod = sampleClass.getDeclaredMethod("privateMethod");
			privateMethod.setAccessible(true);
			privateMethod.invoke(sampleInstance);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
