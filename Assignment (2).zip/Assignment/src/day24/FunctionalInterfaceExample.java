package day24;

import java.util.function.Predicate;
import java.util.function.Function;
import java.util.function.Consumer;
import java.util.function.Supplier;

class Person1 {
	private String name;
	private int age;

	public Person1(String name, int age) {
		this.name = name;
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "Person{name='" + name + "', age=" + age + '}';
	}
}

public class FunctionalInterfaceExample {

	public static void operateOnPerson(Person1 person, Predicate<Person1> predicate, Function<Person1, String> function,
			Consumer<Person1> consumer, Supplier<Person1> supplier) {

		if (predicate.test(person)) {
			System.out.println("Predicate test passed for: " + person);
		} else {
			System.out.println("Predicate test failed for: " + person);
		}

		String result = function.apply(person);
		System.out.println("Function result: " + result);

		consumer.accept(person);
		System.out.println("After Consumer operation: " + person);

		Person1 newPerson = supplier.get();
		System.out.println("New Person from Supplier: " + newPerson);
	}

	public static void main(String[] args) {
		Person1 person = new Person1("Alice", 30);

		Predicate<Person1> agePredicate = p -> p.getAge() > 25;
		Function<Person1, String> nameFunction = Person1::getName;
		Consumer<Person1> ageIncrementConsumer = p -> p.setAge(p.getAge() + 1);
		Supplier<Person1> personSupplier = () -> new Person1("Bob", 40);

		operateOnPerson(person, agePredicate, nameFunction, ageIncrementConsumer, personSupplier);
	}
}
