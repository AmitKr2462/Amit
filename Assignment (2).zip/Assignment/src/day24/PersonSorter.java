/*Task 4: Lambda Expressions
Implement a Comparator for a Person class using a lambda expression, and sort a list of Person objects by their age..*/


package day24;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class PersonSorter {
	public static void main(String[] args) {

		List<Person> people = new ArrayList<>();
		people.add(new Person("Alice", 30));
		people.add(new Person("Bob", 25));
		people.add(new Person("Charlie", 35));
		people.add(new Person("David", 20));

		Comparator<Person> ageComparator = (p1, p2) -> Integer.compare(p1.getAge(), p2.getAge());
		Collections.sort(people, ageComparator);

		System.out.println("Sorted list by age:");
		for (Person person : people) {
			System.out.println(person);
		}
	}
}

class Person {
	private String name;
	private int age;

	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public int getAge() {
		return age;
	}

	@Override
	public String toString() {
		return "Person{name='" + name + "', age=" + age + '}';
	}
}
