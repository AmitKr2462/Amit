/*Task 6: Depth-First Search (DFS) Recursive
Write a recursive DFS function for a given undirected graph. The function should visit every node and print it out.*/

package day14_Assignment_6;

import java.util.*;

public class Graph1 {

	private int numVertices;
	private LinkedList<Integer>[] adjacencyList;

	public Graph1(int numVertices) {
		this.numVertices = numVertices;
		adjacencyList = new LinkedList[numVertices];
		for (int i = 0; i < numVertices; i++) {
			adjacencyList[i] = new LinkedList<>();
		}
	}

	public void addEdge(int src, int dest) {
		adjacencyList[src].add(dest);
		adjacencyList[dest].add(src);
	}

	public void DFS(int startNode) {
		boolean[] visited = new boolean[numVertices];
		DFSUtil(startNode, visited);
	}

	private void DFSUtil(int node, boolean[] visited) {

		visited[node] = true;
		System.out.print(node + " ");

		for (int neighbor : adjacencyList[node]) {
			if (!visited[neighbor]) {
				DFSUtil(neighbor, visited);
			}
		}
	}

	public static void main(String[] args) {

		Graph1 graph = new Graph1(5);

		graph.addEdge(0, 1);
		graph.addEdge(0, 4);
		graph.addEdge(1, 2);
		graph.addEdge(1, 3);
		graph.addEdge(1, 4);
		graph.addEdge(2, 3);
		graph.addEdge(3, 4);

		System.out.println("DFS traversal starting from node 0:");
		graph.DFS(0);
	}

}
