package day23_Assignment_9;

import java.util.*;

public class ArrayUtils {
	public static <T> void swap(T[] array, int index1, int index2) {
		if (index1 >= 0 && index2 >= 0 && index1 < array.length && index2 < array.length) {
			T temp = array[index1];
			array[index1] = array[index2];
			array[index2] = temp;
		} else {
			throw new IndexOutOfBoundsException("Invalid indices for array swap.");
		}
	}

	public static void main(String[] args) {
		
		Integer[] intArray = { 1, 2, 3, 4, 5 };
		System.out.println("Before swap (Integer array): " + Arrays.toString(intArray));
		swap(intArray, 1, 3);
		System.out.println("After swap (Integer array): " + Arrays.toString(intArray));

		
		String[] strArray = { "one", "two", "three", "four" };
		System.out.println("Before swap (String array): " + Arrays.toString(strArray));
		swap(strArray, 0, 2);
		System.out.println("After swap (String array): " + Arrays.toString(strArray));

		
		Pair<Integer, String>[] pairArray = new Pair[] { new Pair<>(1, "one"), new Pair<>(2, "two"),
				new Pair<>(3, "three") };
		System.out.println("Before swap (Pair array): " + Arrays.toString(pairArray));
		swap(pairArray, 0, 2);
		System.out.println("After swap (Pair array): " + Arrays.toString(pairArray));
	}
}

class Pair<T, U> {
	private final T first;
	private final U second;

	public Pair(T first, U second) {
		this.first = first;
		this.second = second;
	}

	public T getFirst() {
		return first;
	}

	public U getSecond() {
		return second;
	}

	@Override
	public String toString() {
		return "Pair{" + "first=" + first + ", second=" + second + '}';
	}
}
