/*Task 3: Job Sequencing Problem
Define a class Job with properties int Id, int Deadline, and int Profit.
Then implement a function List<Job> JobSequencing(List<Job> jobs) that
takes a list of jobs and returns the maximum profit sequence of jobs 
that can be done before the deadlines. Use the greedy method to solve
this problem.*/

package day19;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class Job {
	int Id;
	int Deadline;
	int Profit;

	public Job(int Id, int Deadline, int Profit) {
		this.Id = Id;
		this.Deadline = Deadline;
		this.Profit = Profit;
	}

	@Override
	public String toString() {
		return "Job{Id=" + Id + ", Deadline=" + Deadline + ", Profit=" + Profit + "}";
	}
}

public class JobSequencingProblem {
	public static List<Job> JobSequencing(List<Job> jobs) {

		Collections.sort(jobs, (a, b) -> b.Profit - a.Profit);

		int maxDeadline = 0;
		for (Job job : jobs) {
			if (job.Deadline > maxDeadline) {
				maxDeadline = job.Deadline;
			}
		}

		Job[] result = new Job[maxDeadline + 1];
		boolean[] slot = new boolean[maxDeadline + 1];

		for (Job job : jobs) {

			for (int j = job.Deadline; j > 0; j--) {
				if (!slot[j]) {
					slot[j] = true;
					result[j] = job;
					break;
				}
			}
		}

		List<Job> jobSequence = new ArrayList<>();
		for (int i = 1; i <= maxDeadline; i++) {
			if (slot[i]) {
				jobSequence.add(result[i]);
			}
		}

		return jobSequence;
	}

	public static void main(String[] args) {
		List<Job> jobs = new ArrayList<>();
		jobs.add(new Job(1, 2, 100));
		jobs.add(new Job(2, 1, 19));
		jobs.add(new Job(3, 2, 27));
		jobs.add(new Job(4, 1, 25));
		jobs.add(new Job(5, 3, 15));

		List<Job> maxProfitSequence = JobSequencing(jobs);

		System.out.println("The job sequence with maximum profit is:");
		for (Job job : maxProfitSequence) {
			System.out.println(job);
		}
	}
}
