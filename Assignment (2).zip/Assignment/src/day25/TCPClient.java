package day25;

import java.io.*;
import java.net.Socket;

public class TCPClient {

	public static void main(String[] args) {
		String serverAddress = "localhost";
		int port = 6789;

		OperationRequest request = new OperationRequest(2, 2, "+");

		try (Socket socket = new Socket(serverAddress, port);
				ObjectOutputStream output = new ObjectOutputStream(socket.getOutputStream());
				ObjectInputStream input = new ObjectInputStream(socket.getInputStream())) {

			output.writeObject(request);
			double result = (double) input.readObject();
			System.out.println("Result: " + result);

		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

}
