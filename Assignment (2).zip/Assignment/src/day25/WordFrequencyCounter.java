/*Task 1: Java IO Basics
Write a program that reads a text file and counts the frequency of each word using FileReader and FileWriter.*/
package day25;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class WordFrequencyCounter {

	public static void main(String[] args) {

		String inputFilePath = "D:\\abc.txt";
		String outputFilePath = "D:\\abc2.txt";

		Map<String, Integer> wordCountMap = new HashMap<>();

		try (BufferedReader reader = new BufferedReader(new FileReader(inputFilePath))) {
			String line;
			while ((line = reader.readLine()) != null) {

				String[] words = line.split("\\W+");
				for (String word : words) {
					if (word.isEmpty()) {
						continue;
					}
					word = word.toLowerCase();
					wordCountMap.put(word, wordCountMap.getOrDefault(word, 0) + 1);
				}
			}
		} catch (IOException e) {
			System.err.println("Error reading the input file: " + e.getMessage());
		}

		try (FileWriter writer = new FileWriter(outputFilePath)) {
			for (Map.Entry<String, Integer> entry : wordCountMap.entrySet()) {
				writer.write(entry.getKey() + ": " + entry.getValue() + "\n");
			}
		} catch (IOException e) {
			System.err.println("Error writing to the output file: " + e.getMessage());
		}
	}

}
