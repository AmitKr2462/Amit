package day25;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class TCPServer {

	public static void main(String[] args) {
		try (ServerSocket serverSocket = new ServerSocket(6789)) {
			System.out.println("Server is listening on port 6789");

			while (true) {
				try (Socket socket = serverSocket.accept();
						ObjectInputStream input = new ObjectInputStream(socket.getInputStream());
						ObjectOutputStream output = new ObjectOutputStream(socket.getOutputStream())) {

					OperationRequest request = (OperationRequest) input.readObject();
					double result = processRequest(request);
					output.writeObject(result);
				} catch (IOException | ClassNotFoundException e) {
					e.printStackTrace();
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static double processRequest(OperationRequest request) {
		double number1 = request.getNumber1();
		double number2 = request.getNumber2();
		String operation = request.getOperation();

		switch (operation) {
		case "+":
			return number1 + number2;
		case "-":
			return number1 - number2;
		case "*":
			return number1 * number2;
		case "/":
			if (number2 != 0) {
				return number1 / number2;
			} else {
				throw new ArithmeticException("Division by zero");
			}
		default:
			throw new IllegalArgumentException("Invalid operation: " + operation);
		}
	}

}
