 
/*Task 2: Rat in a Maze
mplement a function bool SolveMaze(int[,] maze) that uses backtracking to find a path 
from the top left corner to the bottom right corner of a maze. The maze is represented by a 
2D array where 1s are paths and 0s are walls. Find a rat's path through the maze. The maze size is 6x6.
*/
package day22;

public class RatInMaze {

	private static final int N = 6;

	private void printSolution(int[][] solution) {
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				System.out.print(" " + solution[i][j] + " ");
			}
			System.out.println();
		}
	}

	public boolean solveMaze(int[][] maze) {
		int[][] solution = new int[N][N];

		if (!solveMazeUtil(maze, 0, 0, solution)) {
			System.out.println("No solution found");
			return false;
		}

		printSolution(solution);
		return true;
	}

	private boolean isSafe(int[][] maze, int x, int y) {

		return (x >= 0 && x < N && y >= 0 && y < N && maze[x][y] == 1);
	}

	private boolean solveMazeUtil(int[][] maze, int x, int y, int[][] solution) {

		if (x == N - 1 && y == N - 1) {
			solution[x][y] = 1;
			return true;
		}

		if (isSafe(maze, x, y)) {

			solution[x][y] = 1;

			if (solveMazeUtil(maze, x + 1, y, solution)) {
				return true;
			}

			if (solveMazeUtil(maze, x, y + 1, solution)) {
				return true;
			}

			solution[x][y] = 0;
			return false;
		}

		return false;
	}

	public static void main(String[] args) {
		RatInMaze rat = new RatInMaze();
		int[][] maze = { { 1, 0, 0, 0, 0, 0 }, { 1, 1, 0, 1, 1, 0 }, { 0, 1, 0, 0, 1, 0 }, { 0, 1, 1, 1, 1, 0 },
				{ 0, 0, 0, 0, 1, 0 }, { 0, 0, 0, 0, 1, 1 } };
		rat.solveMaze(maze);
	}
}
