package com.stack;

public class StackUsingArrays {
	
	int[] s= new int[10];
	int tos;// Top of stack
	 
	StackUsingArrays() {
		tos=-1;
	}
	void push(int item) {
		
		
		
		if (tos==9) {
			System.out.println("Stack is full");
		}
		else {
			
			 tos=tos+1;//0 1
			 s[tos]=item;		
			
		//s[++tos]=item;
		
		}
	}
	int pop() {
		if(tos>=0) {
		return s[tos--];
		}
		else {
			System.out.println("Stack is Empty");
			return -1;
		}
	}
	int peek() {
		return s[tos];
	}
	 
	boolean isEmpty(){
		return tos==-1;
	}

}
