package com.stack;

public class StackDemo {

	public static void main(String[] args) {
		StackUsingArrays s1 = new StackUsingArrays();
		s1.push(5);
		s1.push(6);
		s1.push(8);
		System.out.println(s1.pop());
		StackUsingArrays s2 = new StackUsingArrays();
		s2.push(1);
		s2.push(2);
		s2.push(5);
		System.out.println(s2.peek());
		System.out.println(s2.pop());
		System.out.println(s2.isEmpty());

	}

}
