package com.search;

public class DemoSearch {

	public static void main(String[] args) {
		//Linear Search		
		int[] arr= {1,2,7,4,5,8};
		System.out.println(LinearSearch.find(arr,9));	
		//System.out.println(LinearSearch.contains(arr, 1));
		 
		String name="Maria";
		//System.out.println(LinearSearch.find(name, 'r'));
		//System.out.println(LinearSearch.contains(name, 'M'));
		
		int[] arr1= {1,3,5,6,10,12,15,20,21,28};
		System.out.println(BinarySearch.search(arr1, 1));
		
		int[] arr2= {10,8,6,4,2,0};
		System.out.println(BinarySearch.search(arr2, 18));

	}

}
