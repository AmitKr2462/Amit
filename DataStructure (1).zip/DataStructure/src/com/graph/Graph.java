package com.graph;

import java.util.*;

public class Graph {

	ArrayList<ArrayList<Integer>> adjList = new ArrayList<>();

	Graph(int v) {
		for (int i = 0; i < v; i++) {
			adjList.add(new ArrayList<Integer>());
		}
	}

	public void addEdge(int U, int V) {
		adjList.get(U).add(V);
		adjList.get(V).add(U);
	}

	public void printAdjList() {
		for (int i = 0; i < adjList.size(); i++) {// i-Vertex no
			System.out.println("Adj list of vertex " + i);
			for (int j = 0; j < adjList.get(i).size(); j++) {
				System.out.println(" " + adjList.get(i).get(j));
			}
		}
	}

	public void bfs(int start) {

		Queue<Integer> queue = new LinkedList<>();
		Set<Integer> visited = new HashSet<>();

		queue.add(start);
		visited.add(start);

		while (!queue.isEmpty()) {

			int current = queue.poll();
			System.out.print(current + " ");
			List<Integer> neighbors = adjList.get(current);
			if (neighbors != null) {
				for (int neighbor : neighbors) {
					if (!visited.contains(neighbor)) {
						// If a neighbor has not been visited, mark it visited and enqueue it
						visited.add(neighbor);
						queue.add(neighbor);
					}
				}
			}
		}
	}

	public void dfs(int v) {
		int V = adjList.size();// total no of vertices
		boolean[] visited = new boolean[V];
		dfs2(v, visited);

	}

	public void dfs2(int v, boolean[] visited) {
		visited[v] = true;
		System.out.println(v + " ");
		for (int i = 0; i < adjList.get(v).size(); i++) {
			int av = adjList.get(v).get(i);
			if (!visited[av])
				dfs2(av, visited);

		}
	}

}
