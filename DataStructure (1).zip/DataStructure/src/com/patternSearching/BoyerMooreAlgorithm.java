package com.patternSearching;

import java.util.Arrays;

public class BoyerMooreAlgorithm {

	private int[] preprocessBadCharacter(String pattern) {
		int[] badChar = new int[256];
		Arrays.fill(badChar, -1);
		for (int i = 0; i < pattern.length(); i++) {
			badChar[pattern.charAt(i)] = i;
		}
		return badChar;
	}

	public int search(String text, String pattern) {
		int m = pattern.length();
		int n = text.length();
		int[] badChar = preprocessBadCharacter(pattern);
		int s = 0;
		int lastOccurrence = -1;

		while (s <= (n - m)) {
			int j = m - 1;

			while (j >= 0 && pattern.charAt(j) == text.charAt(s + j)) {
				j--;
			}

			if (j < 0) {
				lastOccurrence = s;
				s += (s + m < n) ? m - badChar[text.charAt(s + m)] : 1;
			} else {

				s += Math.max(1, j - badChar[text.charAt(s + j)]);
			}
		}

		return lastOccurrence;
	}

	public static void main(String[] args) {
		BoyerMooreAlgorithm bm = new BoyerMooreAlgorithm();
		String text = "HERE IS A SIMPLE EXAMPLE";
		String pattern = "EXAMPLE";
		int index = bm.search(text, pattern);
		if (index == -1) {
			System.out.println("Pattern not found");
		} else {
			System.out.println("Pattern found at index " + index);
		}
	}

}
