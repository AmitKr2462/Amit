package day22_Assignment_3;

public class NQueenProblem {

}
