package com.javaio;

import java.io.File;
import java.io.IOException;

public class FileExample {

	public static void main(String[] args) throws IOException {
		File f = new File("abc.txt");
		System.out.println(f.exists());// false
		f.createNewFile();// to create a file
		System.out.println(f.exists());// true
		/*
		 * // Important Methods of file class f.exists(); f.createNewFile(); f.mkdir();
		 * f.isFile(); f.isDirectory(); f.list();//all files present in directory
		 * f.length();
		 */
	}

}
