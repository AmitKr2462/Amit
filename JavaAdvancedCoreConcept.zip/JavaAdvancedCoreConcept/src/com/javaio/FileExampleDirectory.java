package com.javaio;

import java.io.File;
import java.io.IOException;

public class FileExampleDirectory {

	public static void main(String[] args) throws IOException {
		File f = new File("vinayDir");
		// File f=new File("vinayDir","vinay.txt");
		System.out.println(f.exists());
		f.mkdir();// To create a directory

		System.out.println(f.exists());

	}

}
