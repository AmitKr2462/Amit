package com.functionalprogramming;

import java.util.*;
import java.util.function.*;

public class MethodReferenceExample {

	public static void main(String[] args) {

		Consumer<String> print = System.out::println;
		print.accept("Hello, World!");

		String str = "Hello, World!";
		Supplier<Integer> lengthSupplier = str::length;
		System.out.println(lengthSupplier.get());

		Function<String, Integer> lengthFunction = String::length;
		System.out.println(lengthFunction.apply("Hello"));

		Supplier<List<String>> listSupplier = ArrayList::new;
		List<String> list = listSupplier.get();

	}

}